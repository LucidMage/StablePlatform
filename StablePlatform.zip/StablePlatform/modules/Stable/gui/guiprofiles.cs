if(!isObject(GuiDefaultProfile)) new GuiControlProfile (GuiDefaultProfile)
{
    Modal = true;   //  Allow for user input
};